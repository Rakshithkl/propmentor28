import React, { Component } from "react";
import { reactLocalStorage } from 'reactjs-localstorage';
import MuiThemeProvider from "material-ui/styles/MuiThemeProvider";
import injectTapEventPlugin from "react-tap-event-plugin";
import { Switch,Route } from 'react-router-dom';

import "./App.css";
import Login from '../loginpage/loginpage';
import Customer from  '../user/customer';
import CrmComponent from '../user/crm';
import BdmComponent from '../user/bdm';
import Manager from '../user/manager';
import Director from "../user/director";
import CustomerList from '../user/customerlist'
import EdiCust from "../user/editCustomer";

injectTapEventPlugin();

class App extends Component {
  state = {
    data: [],
    username:""
  };

  render() {
    const { username,type } = reactLocalStorage.getObject('user')
    return ( 
      <MuiThemeProvider>
        <div className="App">
          <Switch  >
            <Route exact path="/login" component={Login}/>
            
            { 
              username  &&
                <Route exact path="/" component={CustomerList}/>             
            }
            {
              username && 
                <Route exact path="/addCustomer" component={Customer}/>                               
            }
            {
              username &&
                <Route exact path='/editCustomer/:c_id' component={EdiCust}/>              
            }
            {
              (((type === 'admin')     ||(type==="BDM")||
                (type === "director") ) && (username) ) &&
                <Route exact path="/crm" component={CrmComponent}/>              
            }
            {
              (((type === 'admin') || (type === 'director') ) && (username) ) &&
                <Route exact path="/bdm" component={BdmComponent}/>              
            }
            {
              ((type === 'admin') && (username) ) &&
                <Route exact path="/director" component={Director}/>                                   
            }
            {
              !username  &&
              <Route exact path="/*" component={Login}/>
            }            
          </Switch>
        </div>
      </MuiThemeProvider>
    );
  }
}

export default App;
