import React from 'react';
import { NavItem,Navbar,Nav } from 'react-bootstrap';
import { reactLocalStorage } from 'reactjs-localstorage';
import SVGlogo from './logo1.png';
import './nav.css';

class CustomNavbar extends React.Component{
    logout = () =>{
        this.props.logout()
    }
    render(){
        const { type,firstName } = reactLocalStorage.getObject('user')
        return(
            <div className="nav">
                <Navbar inverse collapseOnSelect>
                    <Navbar.Header>
                        <Navbar.Brand>
                        <a href="/">
                            <img src={ SVGlogo} className="logo"  alt="logo" />
                            PropMentor
                        </a>
                        </Navbar.Brand>
                        <Navbar.Toggle />
                    </Navbar.Header>
                    <Navbar.Collapse>
                        <Nav>
                        {
                            ( (type === 'admin') || (type === 'director') ||
                              (type === 'manager') || (type === 'BDM') ||
                              (type === 'CRM')) &&
                              <NavItem 
                                eventKey={1} 
                                onClick={()=>this.props.goto('/')} 
                                >
                                    Customer List
                                </NavItem>
                        }
                        {
                            ( (type === 'admin') || (type === "director" ) ||
                                (type === "BDM" )  ) &&
                            <NavItem 
                                eventKey={2} 
                                onClick={()=>this.props.goto('/crm')} 
                                >
                                    RM
                                </NavItem>
                        }
                        {
                            ( (type === 'admin') || (type === "director") ) &&
                            <NavItem 
                                eventKey={3} 
                                onClick={()=>this.props.goto('/bdm')}  
                                >
                                    BM
                                </NavItem>
                        }
                        {/* {
                            ( (type === 'admin') ) &&
                            <NavItem 
                                eventKey={4} 
                                onClick={()=>this.props.goto('/manager')} 
                                >
                                    Manager
                                </NavItem>
                        } */}
                        {
                            ( (type === 'admin') ) &&
                            <NavItem 
                                eventKey={5} 
                                onClick={()=>this.props.goto('/director')} 
                                >
                                    Director
                                </NavItem>
                        }
                        
                        </Nav>
                        <Nav pullRight>        
                        <NavItem eventKey={1}>
                            Hi  {firstName}
                        </NavItem> 
                        <NavItem eventKey={1} onClick={this.logout} >
                            Logout
                        </NavItem>
                        </Nav>
                        </Navbar.Collapse> 
                    </Navbar>
            </div>    
        )
    }
}
export default CustomNavbar;