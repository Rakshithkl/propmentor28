import React, { Component } from "react";
import { reactLocalStorage } from 'reactjs-localstorage';
import MuiThemeProvider from "material-ui/styles/MuiThemeProvider";
import { Switch,Route } from 'react-router-dom';

import CustomNavbar from '../navbar/navbar';
import Form from '../form/addDirector';
import EditForm from '../form/editUser';
import MyTable from '../table/AllTable';

class Director extends Component {
    state = {
        data: [],
        editIdx: -1,
        edit:false,
        editing_row:{},
        uname_error:false
    };
  componentDidMount(){
    fetch('/directors/getAll', {
      method: 'GET',
    }).then(res => res.json())
    .then( res => {
      if(res.success){
        this.setState({data:res.directors})
      }
    })
  }
    
  logout = () => {
    reactLocalStorage.setObject('user',{});    
    this.props.history.push('/login')        
  }
  goto = (p) => {
    this.props.history.push(p)
  }
  handleRemove = (i) =>{
    const { username } = this.state.data[i]
    fetch('/directors/delete/' + username  , {
      method: 'GET',
    }).then(res => res.json())
    .then( res => {
      if(res.success){
        this.setState({data:res.directors})
      }
    })
  };
  startEditing = (i) =>{
    this.setState( state => {
      state.edit=true
      state.editing_row=state.data[i]
    });
  };
  add = submission =>{
    const { password,firstName,Phonenumber,email,username} = submission
    fetch('/directors/create', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({firstName,password,Phonenumber,email,username,type:'director' })
    }).then(res => res.json())
    .then( res => {
      if(res.success){
        this.setState({data:res.directors,uname_error:false})
      }else{
        this.setState({uname_error:true})
      }
    })
  }
  update = submission =>{
    const old_username = this.state.editing_row.username
    const { firstName,Phonenumber,username,email,password } =submission
    fetch('/directors/update/' + old_username, {
      method: 'POST',
      headers: {
        'Accept': 'application/json', 
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ firstName,Phonenumber,username,email,password })
    }).then(res => res.json())
    .then( res => {
      if(res.success){ 
        this.setState({data:res.directors,edit:false,editing_row:{}})
      }
    })
  }
  edit = username =>{
    this.setState( state => {
      state.edit=true
      state.editing_row=state.data.filter( director => director.username === username )[0]
    });
  }
  remove = username =>{
    fetch('/directors/delete/' + username  , {
      method: 'GET',
    }).then(res => res.json())
    .then( res => {
      if(res.success){
        this.setState({data:res.directors})
      }
    })
  };
  render() {
    return (
        <div>
          <CustomNavbar 
            logout={this.logout}  
            goto= {  this.goto }
            />
          <h2>Director</h2>
          { !this.state.edit && 
          <Form
            onSubmit={submission =>this.add(submission)}
          />}
          { 
            this.state.uname_error && 
            <p>username already exists</p>
          }
          {
            this.state.edit && 
            <EditForm
              editing_row ={ this.state.editing_row}
              onSubmit = { submission => this.update(submission) }
              />
          }
          <MyTable 
            edit={this.edit}
            remove={this.remove}
            data={this.state.data}
            />
        </div>
    );
  }
}

export default Director;

