import React, { Component } from "react";
import { reactLocalStorage } from 'reactjs-localstorage';

import CustomNavbar from '../navbar/navbar';
import Form from '../form/addBm';
import EditForm from '../form/editUser';
import MyTable from '../table/AllTable';

class BdmComponent extends Component { 
    state = {
        data: [],
        editIdx: -1,
        edit:false,
        editing_row:{},
        uname_error:false
    };
  componentDidMount(){
    const { type,username } = reactLocalStorage.getObject('user')            
    fetch('/bdms/getAll', {
      method: 'GET',
    }).then(res => res.json())
    .then( res => {
      if(res.success){
        if(type === "director" ){
          this.setState({data:res.bdms.filter(bdm => bdm.dir_id === username )})
        }else{
          this.setState({data:res.bdms})
        }
      }
    })
  }
    
  logout = () => {
    reactLocalStorage.setObject('user',{});    
    this.props.history.push('/login')        
  }
  goto = (p) => {
    this.props.history.push(p)
  }
  add = submission =>{
    const { password,firstName,Phonenumber,email,username,dir_id} = submission
    fetch('/bdms/create', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({firstName,password,Phonenumber,email,username,dir_id,type:'BDM' })
    }).then(res => res.json())
    .then( res => {
      if(res.success){
        this.setState({data:res.bdms,uname_error:false})
      }else{
        this.setState({uname_error:true})
      }
    })
  }
  update = submission =>{
    const old_username = this.state.editing_row.username
    const { firstName,Phonenumber,username,email,password } =submission
    fetch('/bdms/update/' + old_username, {
      method: 'POST',
      headers: {
        'Accept': 'application/json', 
        'Content-Type': 'application/json', 
      },
      body: JSON.stringify({ firstName,Phonenumber,username,email,password })
    }).then(res => res.json())
    .then( res => {
      if(res.success){ 
        this.setState({data:res.bdms,edit:false,editing_row:{}})
      }
    })
  }
  edit = username =>{
    this.setState( state => {
      state.edit=true
      state.editing_row=state.data.filter( bm => bm.username === username )[0]
    });
  }
  remove = username =>{
    fetch('/bdms/delete/' + username  , {
      method: 'GET',
    }).then(res => res.json())
    .then( res => {
      if(res.success){
        this.setState({data:res.bdms})
      }
    })
  };
  render() {
    const { type } = reactLocalStorage.getObject('user')    
    return (
        <div>
          <CustomNavbar 
            logout={this.logout}  
            goto= {  this.goto }
            />
          <h2>BMs</h2>
          { (!this.state.edit && ( type === "admin" )  ) && 
          <Form
            onSubmit={submission =>this.add(submission)}
          />}
          { 
            this.state.uname_error && 
            <p>username already exists</p>
          }
          {
            (this.state.edit && (type === "admin") ) && 
            <EditForm
              editing_row ={ this.state.editing_row}
              onSubmit = { submission => this.update(submission) }
              />
          }
          <MyTable 
            user="bm"
            edit={this.edit}
            remove={this.remove}
            data={this.state.data}
            />
          
        </div>
    );
  }
}

export default BdmComponent;

