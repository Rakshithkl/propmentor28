import React, { Component } from "react";
import { reactLocalStorage } from 'reactjs-localstorage';
import CustomNavbar from '../navbar/navbar';
import Form from '../form/addCustomer';
import './customer.css'

class Customer extends Component {
    state = {
        data: [],
        editIdx: -1,
        c_id:0,
        edit:false,
        editing_row:{},
        rm_error : false
    };
  componentDidMount(){
    const { type,username } = reactLocalStorage.getObject('user')
    fetch('/customers/getAll/' + username, {
      method: 'GET',
    }).then(res => res.json())
    .then( res => {
      if(res.success){
        this.setState({data:res.customers})
      }
    }) 
  }
  logout = () => {
    reactLocalStorage.setObject('user',{});    
    this.props.history.push('/login')        
  }
  goto = (p) => {
    this.props.history.push(p)
  }
  handleRemove = (i) =>{
    const { c_id } = this.state.data[i]
    const { username } = reactLocalStorage.getObject('user')
    fetch('/customers/delete/' + c_id + '/' + username, {
      method: 'GET',
    }).then(res => res.json())
    .then( res => {
      if(res.success){
        this.setState({data:res.customers})
      }
    })
  };
  startEditing = (i) =>{
    this.setState(state =>{
      state.edit=true
      state.editing_row=state.data[i]
    });
  };
  stopEditing =() =>{
    this.setState({editIdx: -1});
  };
  handlechange =(e, name, i) =>{
    const {value} = e.target;
    this.setState(state =>({
      data: state.data.map((row,j) => j===i ? {...row, [name]: value} : row)
  }));
  };
  addCustomer = ( submission,bm_id,dir_id) =>{
    const { rm_id, c_Name ,c_Phonenumber,c_email,property,value} =submission

        fetch('/customers/create', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(
        { dir_id,bm_id,rm_id,c_Name,c_Phonenumber,c_email,property,value,
          status:"processing",rm_com:0,bm_com:0,dir_com:0,vp_com:0 })
    }).then(res => res.json())
    .then( res => { 
      if(res.success){
        this.setState({data:res.customers,rm_error:false})
        this.props.history.push('/')
      }else{
        this.setState({rm_error:true})
      }
    }) 
  }
  update = ( submission,crm_id) =>{
    console.log(submission)
    const { c_id } =this.state.editing_row
    const { c_Name ,c_Phonenumber,c_email,property,value} =submission
    fetch('/customers/update/' + c_id, {
      method: 'POST',
      headers: {
        'Accept': 'application/json', 
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ c_Name,c_Phonenumber,c_email,property,value,crm_id })
    }).then(res => res.json())
    .then( res => {
      if(res.success){
        this.setState({data:res.customers,edit:false,editing_row:{}})
      }
    })
  }

  render() {
    const { type,username,dir_id } = reactLocalStorage.getObject('user')
    return (
        <div>
          <CustomNavbar 
            logout={this.logout}  
            goto= {  this.goto }
            />
          <h2>Add Customer</h2>
          <div>
           { !this.state.edit && 
           <Form
              onSubmit={submission => this.addCustomer(submission,username,dir_id) }
           /> }
          { this.state.rm_error ? <p className="rm-error">rm not found</p> : null }
          </div>  
        </div>
    );
  }
}

export default Customer;

