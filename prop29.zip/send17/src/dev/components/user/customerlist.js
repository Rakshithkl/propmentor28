import React, { Component } from "react";
import { reactLocalStorage } from 'reactjs-localstorage';
import CustomNavbar from '../navbar/navbar';
import CusTable from '../table/CusTable';
import './customer.css';

class CustomerList extends Component {
    state = {
        data: [],
        editIdx: -1,
        rm_id:"",
        bm_id:"",
        dir_id:"",
        search:"",
        search_error:false
    };
    componentDidMount(){
      const { type,username } = reactLocalStorage.getObject('user')
        fetch('/customers/getAll', {
          method: 'GET',
        }).then(res => res.json())
        .then( res => {
          if(res.success){
            if( type === "director" ){
              this.setState({data:res.customers.filter(cus => cus.dir_id === username )})
            }else if(type === "BDM" ) {
              this.setState({data:res.customers.filter(cus => cus.bm_id === username )})
            }else if(type === "admin") {
              this.setState({data:res.customers})              
            }
          }
        })
      }
    logout = () => {
      reactLocalStorage.setObject('user',{});    
      this.props.history.push('/login')        
    }
    goto = (p) => {
      this.props.history.push(p)
    }
    handleChange = e =>{
      this.setState({
        [e.target.name]:e.target.value
      })
    }
     search = (srch) =>{
      const { type,username } = reactLocalStorage.getObject('user')      
      if(srch){
        fetch('/customers/getBySearch/'+ srch , {
          method: 'GET',
        }).then(res => res.json())
        .then( res => {
          if(res.success){
            if( type === "director" ){
              this.setState({data:res.customers.filter(cus => cus.dir_id === username )})
            }else if(type === "BDM" ) {
              this.setState({data:res.customers.filter(cus => cus.bm_id === username )})
            }else if(type === "admin") {
              this.setState({data:res.customers})              
            }
            this.setState({search_error:false,search:""})
          }else{
            this.setState({search_error:true})
          }
        })
      }else{
        this.setState({search_error:true})
      }
     }
     edit = c_id => {
      this.props.history.push('/editCustomer/' + c_id )       
      console.log(c_id)
     }
  render() {
    const { rm_id , bm_id , dir_id,search_error,search } =this.state
    const { type } = reactLocalStorage.getObject('user')    
    return (
        <div>
          <CustomNavbar 
            logout={this.logout}  
            goto= {  this.goto }
            />         
          <br/>
          <div className="search" >  
          <input name="search" type='text' onChange={this.handleChange} value={search}/>
          <button onClick={ (e) => this.search(search)}>search</button>
          <span className="heading" > Customer List </span>
          {
            (type === "BDM")  && 
            <button className="add-customer" onClick={()=> this.props.history.push("/addCustomer") }>
              add customer
            </button>
          }
          </div>
          <br /> 

          {
            search_error && 
            <p>please enter valid username </p>
          }
          <CusTable 
            data={this.state.data}
            edit={this.edit}
            />
          
        </div>
    );
  }
}

export default CustomerList;

