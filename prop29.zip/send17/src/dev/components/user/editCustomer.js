import React from "react";
import TextField from "material-ui/TextField";
import RaisedButton from "material-ui/RaisedButton";
import { reactLocalStorage } from 'reactjs-localstorage';
import Dropdown from 'react-dropdown'
import 'react-dropdown/style.css'
import CustomNavbar from '../navbar/navbar';
import  './editCustomer.css';



export default class EdiCust extends React.Component {
  state = {
    c_Name: "",
    c_id:"",
    c_NameError: "",
    c_Phonenumber: "",
    c_PhonenumberError: "",
    c_email: "",
    c_emailError: "",
    property: "",
    propertyError: "",
    value: "",
    valueError: "",
    status:"",
    status_error:"",
    options:["processing","close"],
    commission: 0
  };
  componentDidMount(){
    console.log(this.props.match.params.c_id)
    fetch('/customers/getByCID/' + this.props.match.params.c_id , {
      method: 'GET',
    }).then(res => res.json())
    .then( res => {
      if(res.success){
        this.setState({data:res.customer})
      const {c_id,c_Name,c_Phonenumber,c_email,property,value,commission,state } = res.customer
      this.setState({ c_id,c_Name,c_Phonenumber,c_email,property,state,
                    value,commission})
      }else{
        console.log("fetch failed")
      }
    }) 
      
  }
  logout = () => {
    reactLocalStorage.setObject('user',{});    
    this.props.history.push('/login')        
  }
  goto = (p) => {
    this.props.history.push(p)
  }

  change = e => {
    // this.props.onChange({ [e.target.name]: e.target.value });
    this.setState({
      [e.target.name]: e.target.value
    });
  };
  onStatusChange = e =>{
    this.setState({status:e.value})
  }

  validate = () => {
    let isError = false;
    const errors = {
        c_NameError: "",
        c_PhonenumberError: "",
        c_emailError: "",
        propertyError: "",
        valueError: "",
        status_error:false        
    };

    if (this.state.c_Name.length < 2) {
      isError = true;
      errors.c_NameError = "Username needs to be atleast 2 characters long";
    }

    if (this.state.c_email.indexOf("@") === -1) {
      isError = true;
      errors.c_emailError = "Requires valid email";
    }
    if (this.state.c_Phonenumber.length < 10) {
        isError = true;
        errors.c_PhonenumberError = "Phone number should be 10 Numbers";
      }
      // if(!this.state.status){
      //   isError =true;
      //   errors.status_error=true
      // }
    this.setState({
      ...this.state,
      ...errors
    });

    return isError;
  };

  onSubmit = e => {
    e.preventDefault();
    const err = this.validate();
    if (!err) {
      // this.props.onSubmit(this.state);
      const { c_id,c_Name,c_Phonenumber,c_email,property,value } =this.state
      let status = this.state.status
    let rm_com,bm_com,dir_com,vp_com;
    if(status === "close" ){
      rm_com = value/100*3
      bm_com = value/100*2
      dir_com = value/100*1
      vp_com = value/100*1 
      status = "closed";
      const rm_sms = "your commission is  " + rm_com 
      const bm_sms = "your commission is  " + bm_com 
      const dir_sms = "your commission is  " + dir_com 
      fetch('/customers/sendOtp', {
        method : 'POST',
        headers : {
          'Accept' : 'application/json', 
          'Content-Type' : 'application/json',
        },
        body: JSON.stringify(
          { c_id,rm_sms,bm_sms,dir_sms }
        )
      }).then(res => res.json())
      .then( res => {
        console.log('yes')
      } )
    }else{
      rm_com = 0
      bm_com = 0
      dir_com = 0
      vp_com = 0
      status = "processing" 
    }  
    fetch('/customers/update/' + c_id, {
      method : 'POST',
      headers : {
        'Accept' : 'application/json', 
        'Content-Type' : 'application/json',
      },
      body: JSON.stringify(
        { c_Name,c_Phonenumber,c_email,property,value,status,rm_com,
          bm_com,dir_com,vp_com }
      )
    }).then(res => res.json())
    .then( res => {
      if(res.success){
        this.props.history.push('/')
      }
    })
      // clear form
      this.setState({
        c_Name: "",
    c_NameError: "",
    c_Phonenumber: "",
    c_PhonenumberError: "",
    c_email: "",
    c_emailError: "",
    property: "",
    propertyError: "",
    value: "",
    valueError: "",
    state:"",
    status_error:false
      });
    }
  };

  render() {
    const { options } =this.state    
    const defaultOption = options[0]
    const { type } = reactLocalStorage.getObject('user') 
    console.log(this.state.staus)   
    
    return (
      <div>
        <CustomNavbar 
            logout={this.logout}  
            goto= {  this.goto }
            />
      <form> 
        <TextField
          name="c_Name"
          hintText="Name"
          floatingLabelText="Nname"
          value={this.state.c_Name}
          onChange={e => this.change(e)}
          errorText={this.state.c_NameError}
          floatingLabelFixed
        />
        <br />
        <TextField
          name="c_Phonenumber"
          hintText="Phonenumber"
          floatingLabelText="Phonenumber"
          value={this.state.c_Phonenumber}
          onChange={e => this.change(e)}
          errorText={this.state.c_PhonenumberError}
          type="number"
          floatingLabelFixed
        />
        <br />
        <TextField
          name="c_email"
          hintText="Email"
          floatingLabelText="Email"
          value={this.state.c_email}
          onChange={e => this.change(e)}
          errorText={this.state.c_emailError}
          floatingLabelFixed
        />
        <br />
        <TextField
          name="property"
          hintText="property"
          floatingLabelText="property"
          value={this.state.property}
          onChange={e => this.change(e)}
          errorText={this.state.propertyError}
          floatingLabelFixed
        />
        <br />
        <TextField
          name="value"
          hintText="value"
          floatingLabelText="value"
          value={this.state.value}
          onChange={e => this.change(e)}
          errorText={this.state.valueError}
          type="number"
          floatingLabelFixed
        />
        <br />
        {/* { type === "admin" && */}
          <Dropdown className="edit-customer"
          options={options} 
          onChange={this.onStatusChange} 
          value={defaultOption} 
          // placeholder="Select an option"
          />
          {/* } */}
        <RaisedButton label="Save" onClick={e => this.onSubmit(e)} primary />
      </form>
      </div>
    );
  }
}
