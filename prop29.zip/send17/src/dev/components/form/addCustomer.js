import React from "react";
import TextField from "material-ui/TextField";
import RaisedButton from "material-ui/RaisedButton";
import Dropdown from 'react-dropdown'
import 'react-dropdown/style.css'

export default class Form extends React.Component {
  state = {
    dir_id:"",
    dir_id_error:"",
    rm_id:"",
    rm_id_errr:"",
    c_Name: "",
    c_NameError: "",
    c_Phonenumber: "",
    c_PhonenumberError: "",
    c_email: "",
    c_emailError: "",
    property: "",
    propertyError: "",
    value: "",
    valueError: "",
    status:"",
    // status_error:"",
    // options:[1,2,3]
  };

  change = e => {
    // this.props.onChange({ [e.target.name]: e.target.value });
    this.setState({
      [e.target.name]: e.target.value
    });
  };
  // onStatusChange = e =>{
  //   this.setState({status:e.value})
  // }

  validate = () => {
    let isError = false;
    const errors = {
      dir_id_error:"",
      rm_id_errr:"",
        c_NameError: "",
        c_PhonenumberError: "",
        c_emailError: "",
        propertyError: "",
        valueError: "",
        // status_error:false
    };

    if (this.state.c_Name.length < 2) {
      isError = true;
      errors.c_NameError = "Username needs to be atleast 2 characters long";
    }

    if (this.state.c_email.indexOf("@") === -1) {
      isError = true;
      errors.c_emailError = "Requires valid email";
    }
    if (this.state.c_Phonenumber.length < 10) {
        isError = true;
        errors.c_PhonenumberError = "Phone number should be 10 Numbers";
      }

    this.setState({
      ...this.state,
      ...errors
    });

    return isError; 
  };

  onSubmit = e => {
    e.preventDefault();
    const err = this.validate();
    if (!err) {
      this.props.onSubmit(this.state);
      // clear form
      this.setState({
        dir_id:"",
        dir_id_error:"",
        c_Name: "",
    c_NameError: "",
    rm_id:"",
    rm_id_errr:"",
    c_Phonenumber: "",
    c_PhonenumberError: "",
    c_email: "",
    c_emailError: "",
    property: "",
    propertyError: "",
    value: "",
    valueError: "",
    status:""
      });
    }
  };

  render() {
    // const { options } =this.state
    return (
      <form>
        <TextField
          name="rm_id"
          hintText="rm_id"
          floatingLabelText="rm_id"
          value={this.state.rm_id}
          onChange={e => this.change(e)}
          errorText={this.state.rm_id_errr}
          floatingLabelFixed
        />
        <br />
        <TextField
          name="c_Name"
          hintText="Name"
          floatingLabelText="Nname"
          value={this.state.c_Name}
          onChange={e => this.change(e)}
          errorText={this.state.c_NameError}
          floatingLabelFixed
        />
        <br />
        <TextField
          name="c_Phonenumber"
          hintText="Phonenumber"
          floatingLabelText="Phonenumber"
          value={this.state.c_Phonenumber}
          onChange={e => this.change(e)}
          errorText={this.state.c_PhonenumberError}
          type="number"
          floatingLabelFixed
        />
        <br />
        <TextField
          name="c_email"
          hintText="Email"
          floatingLabelText="Email"
          value={this.state.c_email}
          onChange={e => this.change(e)}
          errorText={this.state.c_emailError}
          floatingLabelFixed
        />
        <br />
        <TextField
          name="property"
          hintText="property"
          floatingLabelText="property"
          value={this.state.property}
          onChange={e => this.change(e)}
          errorText={this.state.propertyError}
          floatingLabelFixed
        />
        <br />
        <TextField
          name="value"
          hintText="value"
          floatingLabelText="value"
          value={this.state.value}
          onChange={e => this.change(e)}
          errorText={this.state.valueError}
          type="number"
          floatingLabelFixed
        />
        <br />
        <RaisedButton label="Submit" onClick={e => this.onSubmit(e)} primary />
      </form>
    );
  }
}
