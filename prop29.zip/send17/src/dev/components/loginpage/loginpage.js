import React, { Component } from "react";
import { reactLocalStorage } from 'reactjs-localstorage';
import { Button, FormGroup, FormControl, ControlLabel,DropdownButton,MenuItem } from "react-bootstrap";
import "./loginpages.css";

export default class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      password: "",
      credentials_err:false,
      type:''
    };
  }
  componentDidMount(){
    reactLocalStorage.setObject('user',{});    
  }

  validateForm() {
    return this.state.username.length > 0 && this.state.password.length > 0;
  }

  handleChange = event => {
    this.setState({
      [event.target.name]: event.target.value
    });
  }

  handleSubmit = event => {
    const { type,username,password } = this.state
    if( username === 'admin' && password === 'admin' && type === 'admin'){      
      reactLocalStorage.setObject('user',{username,type,firstName:"admin"})
      this.props.history.push('/')
    }else{
      fetch('/'+ type + 's/login/' + username +'/' +password  , {
        method: 'GET',
      }).then(res => res.json()) 
      .then( res => {
        if(res.success){
          const { firstName,username,password,type } = res.user
          reactLocalStorage.setObject('user',{firstName,username,type})
          if( type === "BDM" ){
            const { dir_id } = res.user
            reactLocalStorage.setObject('user',{firstName,username,type,dir_id})            
          }
          this.props.history.push('/')
        }else{
          this.setState({credentials_err:true})
        }
      })
    }
    // let user ={username:'admin',password:'admin',name:"naresh",type:"admin"}
    // const {username,password,name,type } = user
    // if( username === this.state.username && password === this.state.password ){
    //   reactLocalStorage.setObject('user',{username,password,name,type});      
    //   this.props.history.push('/')
    // }else{
    //   this.setState({credentials_err:true})
    // }
    event.preventDefault(); 
  }
  render() {
    return (
      <div className="Login"> 
        <form >
          <FormGroup bsSize="large">
            <ControlLabel>ID</ControlLabel>
            <FormControl
              autoFocus
              type="text"
              name="username"
              value={this.state.username}
              onChange={this.handleChange}
            />
          </FormGroup>
          <FormGroup bsSize="large">
            <ControlLabel>Password</ControlLabel>
            <FormControl
              value={this.state.password}
              name="password"
              onChange={this.handleChange}
              type="password"
            />
          </FormGroup>
          <FormGroup bsSize="large">
            <ControlLabel>Type</ControlLabel>
            <FormControl
              value={this.state.type}
              name="type"
              onChange={this.handleChange}
            />
          </FormGroup>
          { this.state.credentials_err && 
            <p> you entered wrong id or password </p> }
            
          <Button
            block
            bsSize="large"
            disabled={!this.validateForm()}
            onClick={this.handleSubmit}
            type="submit"
          >
            Login
          </Button>
        </form>
      </div>
    );
  }
}