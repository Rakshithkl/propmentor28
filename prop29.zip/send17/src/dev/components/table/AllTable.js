import React from 'react';
import { Table,Button } from 'react-bootstrap';
import { reactLocalStorage } from 'reactjs-localstorage';
import Modal from 'react-responsive-modal';

import './table.css'

export default class MyTable extends React.Component{
    state={
        is_modal_open: false
    }
    render(){
        const { type } = reactLocalStorage.getObject('user')        
        const { data } = this.props
        return(
            <div>
                <Table striped bordered condensed hover responsive>
                    <thead>
                    <tr className="">
                        { ((this.props.user === "rm") || (this.props.user === "bm" ) ) ?
                            <th>Dir_ID</th> : null
                        }
                        { (this.props.user === "rm") ?
                        <th>BM_ID</th> : null
                        }
                        <th className="center" >First Name</th>
                        <th className="center"> Phone Number </th>
                        <th className="center">User Name </th>
                        <th className="center"> Email </th>
                        <th className="center"> Password </th>
                        {/* <th></th>
                        <th></th> */}
                    </tr>
                    </thead>
                    <tbody>   
                    { 
                    data.map((x,i)=> {
                        const { username } = x
                        return (
                        <tr key={i} >
                            { x.dir_id ? <td>{x.dir_id} </td> : null }
                            { x.bm_id ? <td>{x.bm_id} </td> : null}
                            <td>{x.firstName} </td>
                            <td>{x.Phonenumber} </td>
                            <td>{x.username} </td>
                            <td>{x.email} </td>
                            <td>{x.password} </td>
                            { type === "admin"  ?
                            <td className="cursor-pointer" onClick={ ()=>this.props.edit(username) } >
                            Edit</td> : null
                            }
                            { type === "admin" ?
                            <td className="cursor-pointer" onClick={ ()=>this.setState({is_modal_open:true}) } >
                                Delete
                                <Modal
                                    open={this.state.is_modal_open}
                                    onClose={ ()=> this.setState({is_modal_open:false}) }
                                    center
                                    classNames={{
                                        transitionEnter: 'transition-enter',
                                        transitionEnterActive: 'transition-enter-active',
                                        transitionExit: 'transition-exit-active',
                                        transitionExitActive: 'transition-exit-active',
                                    }}
                                    animationDuration={1000}
                                    >
                                    <p className="modal-text">
                                        Are you sure you want to delete this user
                                    </p>
                                    <Button onClick={ ()=>{
                                        this.props.remove(username)
                                        this.setState({is_modal_open:false})
                                        } }
                                        className="modal-yes-button"
                                        >
                                        yes
                                    </Button>
                                    <Button onClick={()=>{
                                        this.setState({is_modal_open:false})
                                        }}>
                                        No
                                    </Button>    
                                </Modal>
                            </td> : null
                            }
                        </tr>    
                    )
                    }) 
                } 
                </tbody>
                </Table>
            </div>    
        )
    }
}