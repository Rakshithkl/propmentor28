import React from 'react';
import { Table } from 'react-bootstrap';
import { reactLocalStorage } from 'reactjs-localstorage';


export default class CusTable extends React.Component{
    render(){
        const { type } = reactLocalStorage.getObject('user')        
        const { data } = this.props
        return(
            <div className="style">
                <Table striped bordered condensed hover responsive>
                    <thead>
                    <tr>
                        <th>S.No</th>
                        {
                            type === "admin"  ?
                            <th>Dir_ID</th> : null
                        }
                        {
                            (type === "director" || type === "admin" ) ?
                            <th>BM_Id</th>  : null
                        }
                        <th>RM_ID</th>
                        <th>Name</th>
                        <th>Phone Number </th>
                        <th> Email </th>
                        <th> Property </th>
                        <th> Value </th>
                        <th> Status </th>
                        {
                            (type === "CRM" || type === "admin" ) ? 
                            <th> RM Comm </th> : null 
                        }
                        {
                            (type === "BDM" || type === "admin" ) ?
                            <th> BM Comm </th> : null
                        }
                        {
                            (type === "director" || type === "admin" ) ?
                            <th> Dir comm </th> : null
                        }
                        {
                            type === "admin" ?
                            <th> VP Comm </th> : null
                        }    
                        {/* <th></th>
                        <th></th> */}
                    </tr>
                    </thead>
                    <tbody>   
                    { 
                    data.map((x,i)=> {
                        const { c_id } = x
                        return (
                        <tr key={i} >
                            <td>{i+1}</td>
                            {
                                type === "admin"  ?
                                <td>{x.dir_id} </td> : null
                            }
                            {
                                (type === "director" || type === "admin" ) ?
                                <td>{x.bm_id} </td> : null
                            }
                            <td>{x.rm_id} </td>
                            <td>{x.c_Name} </td>
                            <td>{x.c_Phonenumber} </td>
                            <td>{x.c_email} </td>
                            <td>{x.property} </td>
                            <td>{x.value} </td>
                            <td>{x.status} </td>
                            {
                                (type === "CRM" || type === "admin" ) ? 
                                <td>{x.rm_com} </td> : null
                            }
                            {
                                (type === "BDM" || type === "admin" ) ?
                                <td>{x.bm_com} </td> : null
                            }
                            {
                                (type === "director" || type === "admin" ) ?
                                <td>{x.dir_com} </td> : null
                            }
                            {
                                type === "admin" ?
                                <td>{x.vp_com} </td> :null                                
                            }
                            { ((type === "admin") && (x.status === "processing") )  &&
                            <td className="cursor-pointer" onClick={ ()=>this.props.edit(c_id) } >edit</td>
                            }
                        </tr>    
                    )
                    }) 
                } 
                </tbody>
                </Table>
            </div>    
        )
    }
}