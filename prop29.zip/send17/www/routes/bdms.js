var express = require('express');
var bdm = require('../models/bdm');
var router = express.Router()

router.get('/getAll',(req,res)=>{
    bdm.find((err,bdms)=>{
        res.json({success:true,bdms})
    })
})
router.post('/create',(req,res)=>{
    const { username } = req.body
    bdm.find({username}, (err,bdms)=>{
        if(bdms[0]){
            res.json({success:false})
        }else{
            bdm.create(req.body,(err,bdms)=>{
                bdm.find((err,bdms)=>{
                    res.json({success:true,bdms})
                })
            })
        }
    })
})
router.post('/update/:username',(req,res)=>{
    const { username } = req.params
    bdm.findOneAndUpdate({ username },req.body,(err,data)=>{
        bdm.find((err,bdms)=>{
            res.json({success:true,bdms})
        })
    })
})
router.get('/delete/:username',(req,res)=>{
    const { username } =req.params
    bdm.findOneAndRemove({username},(err,data)=>{
        bdm.find((err,bdms)=>{
            res.json({success:true,bdms})
        })
    })
})
router.get('/login/:username/:password',(req,res)=>{
    const { username,password } = req.params
    bdm.findOne({username,password},(err,user)=>{
        if(err) console.log(err)
        if(user){
            res.json({success:true,user})
        }else{ 
            res.json({success:false})
        }
    })
})
module.exports =router; 