var express = require('express');
var director = require('../models/admin');
var router = express.Router()


router.post('/create',(req,res)=>{
    const { username } = req.body
    director.find({username}, (err,directors)=>{
        if(directors[0]){
            res.json({success:false})
        }else{
            director.create(req.body,(err,directors)=>{
                director.find((err,directors)=>{
                    res.json({success:true,directors})
                })
            })
        }
    })
})
router.get('/login/:username/:password',(req,res)=>{
    const { username,password } = req.params
    director.findOne({username,password},(err,user)=>{
        if(err) console.log(err)
        if(user){
            res.json({success:true,user})
        }else{ 
            res.json({success:false})
        }
    })
})
module.exports =router; 