var express = require('express');
var manager = require('../models//manager');
var router = express.Router()

router.get('/getAll',(req,res)=>{
    manager.find((err,managers)=>{
        res.json({success:true,managers})
    })
})
router.post('/create',(req,res)=>{
    const { username } = req.body
    manager.find({username}, (err,managers)=>{
        if(managers[0]){
            res.json({success:false})
        }else{
            manager.create(req.body,(err,managers)=>{
                manager.find((err,managers)=>{
                    res.json({success:true,managers})
                })
            })
        }
    })
})
router.post('/update/:username',(req,res)=>{
    const { username } = req.params
    manager.findOneAndUpdate({ username },req.body,(err,data)=>{
        manager.find((err,managers)=>{
            res.json({success:true,managers})
        })
    })
})
router.get('/delete/:username',(req,res)=>{
    const { username } =req.params
    manager.findOneAndRemove({username},(err,data)=>{
        manager.find((err,managers)=>{
            res.json({success:true,managers})
        })
    })
})
router.get('/login/:username/:password',(req,res)=>{
    const { username,password } = req.params
    director.findOne({username,password},(err,user)=>{
        if(err) console.log(err)
        if(user){
            res.json({success:true,user})
        }else{ 
            res.json({success:false})
        }
    })
})
module.exports =router; 