var express = require('express');
var crm = require('../models/crm');
var router = express.Router()

router.get('/getAll',(req,res)=>{
    crm.find((err,crms)=>{
        res.json({success:true,crms})
    })
})
router.post('/create',(req,res)=>{
    const { username } = req.body
    crm.find({username}, (err,crms)=>{
        if(crms[0]){
            res.json({success:false})
        }else{
            crm.create(req.body,(err,crms)=>{
                crm.find((err,crms)=>{
                    res.json({success:true,crms})
                })
            })
        }
    })
})
router.post('/update/:username',(req,res)=>{ 
    const { username } = req.params
    crm.findOneAndUpdate({ username },req.body,(err,data)=>{
        crm.find((err,crms)=>{
            res.json({success:true,crms})
        })
    })
})
router.get('/delete/:username',(req,res)=>{
    const { username } =req.params
    crm.findOneAndRemove({username},(err,data)=>{
        crm.find((err,crms)=>{
            res.json({success:true,crms})
        })
    })
})
router.get('/login/:username/:password',(req,res)=>{
    const { username,password } = req.params
    crm.findOne({username,password},(err,user)=>{
        if(err) console.log(err)
        if(user){
            res.json({success:true,user})
        }else{ 
            res.json({success:false})
        }
    })
})
module.exports =router; 