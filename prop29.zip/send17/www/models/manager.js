var mongoose =require('mongoose');

var schema = new mongoose.Schema({
    firstName: String,
    username: String,
    Phonenumber: String, 
    email: String, 
    password: String,
})

module.exports =mongoose.model('manager',schema)