var mongoose =require('mongoose');

var schema = new mongoose.Schema({
    c_id: String,
    rm_id:String,
    bm_id:String,
    dir_id:String,
    c_Name: String,
    c_Phonenumber: String, 
    c_email: String,
    property: String,
    value: Number,
    status: String,
    commission:Number,
    rm_com:Number,
    bm_com:Number,
    dir_com:Number,
    vp_com:Number,
})

module.exports =mongoose.model('customer',schema)