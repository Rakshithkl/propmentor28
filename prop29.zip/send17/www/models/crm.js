var mongoose =require('mongoose');

var schema = new mongoose.Schema({
    dir_id: String,
    bm_id: String,
    firstName: String,
    username: String,
    Phonenumber: String, 
    email: String,
    password: String,
    type: String
})

module.exports =mongoose.model('crm',schema)