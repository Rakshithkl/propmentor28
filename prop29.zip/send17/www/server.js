var express    = require('express')
var path       = require('path')
var fs         = require('fs')
var mongoose   = require('mongoose')
var bodyParser =require('body-parser');
var passport   =require("passport");

var customers = require('./routes/customers');
var crms      = require('./routes/crms');
var bdms      = require('./routes/bdms');
var managers  = require('./routes/managers');
var directors = require('./routes/directors');

var app =express();

mongoose.connect('mongodb://localhost/propmentor')

app.use(bodyParser.urlencoded({ extended: false }))
 
// parse application/json
app.use(bodyParser.json())


app.use(express.static(path.resolve(__dirname,  '../dist')));
app.get('/', (req, res) => {
    res.sendFile(path.resolve(__dirname,  '../dist', 'index.html'));
});
// app.get('/login', function(req, res, next) {
//     passport.authenticate('local', function(err, user, info) {
//       if (err) { return next(err); }
//       if (!user) { return res.redirect('/login'); }
//       req.logIn(user, function(err) {
//         if (err) { return next(err); }
//         return res.redirect('/users/' + user.username);
//       });
//     })(req, res, next);
//   });

app.use('/customers',customers)
app.use('/crms',crms)
app.use('/bdms',bdms)
app.use('/managers',managers)
app.use('/directors',directors)
app.listen(100,()=> console.log("successs"))