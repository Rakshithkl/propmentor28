# basic-react-form

[Watch the YouTube video to learn how it was made.](https://youtu.be/WIwiqZCraQ4)
